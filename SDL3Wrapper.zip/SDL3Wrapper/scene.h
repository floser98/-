
#pragma once
#include <vector>
#include <cstdint>

typedef struct {
    SDL_FRect fRect;
    uint8_t color[4];
} Rect;

static class SceneAgregator {
private:
    static inline std::vector<Rect> objects;

public:
    static void appendRect(float x, float y, float w, float h,
                           uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
        Rect rect;
        rect.fRect.x = x;
        rect.fRect.y = y;
        rect.fRect.w = w;
        rect.fRect.h = h;
        rect.color[0] = r;
        rect.color[1] = g;
        rect.color[2] = b;
        rect.color[3] = a;
        objects.push_back(rect);
    }

    static const std::vector<Rect>& collect() {
        return objects;
    }

    static void clear() {
        objects.clear();
    }
};
