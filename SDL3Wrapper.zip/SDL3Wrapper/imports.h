#ifndef ALL_HEADERS_H
#define ALL_HEADERS_H

#include "sdl3_consts.h"
#include "sdl3_defs.h"
#include "sdl3_render.h"
#include "sdl3_sys.h"
#include "sdl3_windows.h"
#include "sdl3.h"
#include "config.h"
#include "scene.h"
#include <iostream>
#include <cstdlib>

#endif