#pragma once

inline void* sdl3_create_renderer(HMODULE sdl3, void* window) {
	SDL_CreateRenderer _sdl3_create_renderer = (SDL_CreateRenderer)GetProcAddress(sdl3, "SDL_CreateRenderer");
	if (!_sdl3_create_renderer) {
		std::cerr << "Fail to load SDL_CreateRenderer, error: " << GetLastError() << std::endl;
		FreeLibrary(sdl3);
		exit(1);
	}
	void* renderer = _sdl3_create_renderer(window, NULL);
	if (!renderer) {
		std::cerr << "Fail to create renderer, error: " << GetLastError() << std::endl;
		FreeLibrary(sdl3);
		exit(1);
	}
	return renderer;
}

bool sdl3_destroy_renderer(HMODULE lib, void* renderer) {
	PFN_SDL_DestroyRenderer _sdl3_destroy_renderer = (PFN_SDL_DestroyRenderer)GetProcAddress(lib, "SDL_DestroyRenderer");
	if (!_sdl3_destroy_renderer) {
		std::cerr << "Failed to load SDL_DestroyRenderer, error: " << GetLastError() << std::endl;
		return false;
	}
	_sdl3_destroy_renderer(renderer);
	return true;
}

bool sdl3_render_clear(HMODULE sdl3, void* renderer) {
	SDL_RenderClear _sdl3_render_clear = (SDL_RenderClear)GetProcAddress(sdl3, "SDL_RenderClear");
	if (!_sdl3_render_clear) {
		std::cerr << "Fail to load SDL_RenderClear, error: " << GetLastError() << std::endl;
		FreeLibrary(sdl3);
		exit(1);
	}
	return _sdl3_render_clear(renderer);
}

bool sdl3_render_fill_rect(HMODULE sdl3, void* renderer, SDL_FRect rect) {
	SDL_RenderFillRect _sdl3_render_fill_rect = (SDL_RenderFillRect)GetProcAddress(sdl3, "SDL_RenderFillRect");
	if (!_sdl3_render_fill_rect) {
		std::cerr << "Fail to load SDL_RenderFillRect, error: " << GetLastError() << std::endl;
		FreeLibrary(sdl3);
		exit(1);
	}
	return _sdl3_render_fill_rect(renderer, &rect);
}

inline bool sdl3_render_draw_line(HMODULE sdl3, void* renderer, float x1, float y1, float x2, float y2) {
	SDL_RenderLine _draw_line = (SDL_RenderLine)GetProcAddress(sdl3, "SDL_RenderLine");
	if (!_draw_line) {
		std::cerr << "Fail to load SDL_RenderDrawLine: " << GetLastError() << std::endl;
		FreeLibrary(sdl3);
		exit(1);
	}
	return _draw_line(renderer, x1, y1, x2, y2);
}


bool sdl3_set_render_draw_color(HMODULE sdl3, void* renderer, uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
	SDL_SetRenderDrawColor _sdl3_set_render_draw_color = (SDL_SetRenderDrawColor)GetProcAddress(sdl3, "SDL_SetRenderDrawColor");
	if (!_sdl3_set_render_draw_color) {
		std::cerr << "Fail to load SDL_SetRenderDrawColor, error: " << GetLastError() << std::endl;
		FreeLibrary(sdl3);
		exit(1);
	}
	return _sdl3_set_render_draw_color(renderer, r, g, b, a);
}

bool sdl3_render_present(HMODULE sdl3, void* renderer) {
	SDL_RenderPresent _sdl3_render_present = (SDL_RenderPresent)GetProcAddress(sdl3, "SDL_RenderPresent");
	if (!_sdl3_render_present) {
		std::cerr << "Fail to load SDL_RenderPresent, error: " << GetLastError() << std::endl;
		FreeLibrary(sdl3);
		exit(1);
	}
	return _sdl3_render_present(renderer);
}