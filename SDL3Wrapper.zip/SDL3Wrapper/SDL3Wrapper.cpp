
#include <iostream>
#include "imports.h"

int main() {
    SDL3* sdl3 = Configurator::SDL_Config(
        SDL_InitFlags().SDL_INIT_ALL,
        SDL_WindowFlags().SDL_WINDOW_OPENGL + SDL_WindowFlags().SDL_WINDOW_RESIZABLE,
        "AI Startup Viewer",
        800,
        600
    );

    SceneAgregator::appendRect(100, 100, 100, 100, 255, 0, 0, 255);
    SceneAgregator::appendRect(233, 50, 100, 100, 0, 255, 0, 255);
    SceneAgregator::appendRect(400, 150, 100, 100, 0, 0, 255, 255);
    SceneAgregator::appendRect(320, 300, 100, 100, 255, 128, 89, 255);

    bool run = true;
    while (run) {
        SDL_Event event;
        while (sdl3->pollEvent(&event)) {
            if (event.type == 0x100) {
                run = false;
                break;
            }
        }

        sdl3->getRenderer()->setDrawColor(0, 0, 0, 255);
        sdl3->getRenderer()->clear();

        for (const auto& object : SceneAgregator::collect()) {
            sdl3->getRenderer()->setDrawColor(
                object.color[0], object.color[1], object.color[2], object.color[3]);
            sdl3->getRenderer()->fillRect(object.fRect);
        }

        sdl3->getRenderer()->present();
        sdl3->Delay(16);
    }

    SceneAgregator::clear();
    delete sdl3;
    std::cout << "Ended correctly" << std::endl;
    return 0;
}
