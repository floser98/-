#include <memory>

class Window {
public:
	Window(HMODULE lib, std::string title, int w, int h, uint64_t window_flags)
		: lib_(lib) {
		window_ = sdl3_create_window(lib, title, w, h, window_flags);
	}

	~Window() {
		if (window_ != nullptr) {
			sdl3_destroy_window(lib_, window_);
		}
	} 

	void* raw() const {
		return window_;
	}

private:
	HMODULE lib_;
	void* window_ = nullptr;
};

class Render {
public:
	Render(HMODULE lib, void* window)
	: lib_(lib) {
		renderer_ = sdl3_create_renderer(lib, window);
	}

	~Render() {
		if (renderer_ != nullptr) {
			sdl3_destroy_renderer(lib_, renderer_);
		}
	}
	
	void setDrawColor(uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
		sdl3_set_render_draw_color(lib_, renderer_, r, g, b, a);
	}

	void clear() {
		sdl3_render_clear(lib_, renderer_);
	}

	void present() {
		sdl3_render_present(lib_, renderer_);
	}

	void fillRect(SDL_FRect rect) {
		sdl3_render_fill_rect(lib_, renderer_, rect);
	}

private:
	HMODULE lib_;
	void* renderer_ = nullptr;
};

class SDL3 {
public:
	SDL3(uint32_t init_flags) {
		lib = sdl3_load();
		bool init_response = sdl3_init(lib, init_flags);
		if (!init_response) {
			std::cerr << "Can't initialize sdl3" << std::endl;
			exit(1);
		}
	}

	~SDL3() {
		sdl3_quit(lib);
		std::cout << "SDL3 free successefully" << std::endl;
	}

	void createWindow(std::string title, int w, int h, uint64_t window_flags) {
		window = std::make_unique<Window>(lib, title, w, h, window_flags);
	}

	void createRenderer() {
		if (window) {
			renderer = std::make_unique<Render>(lib, window->raw());
		}
	}

	void Delay(Uint32 ms) {
		sdl3_delay(lib, ms);
	}

	Render* getRenderer() {
		return renderer.get();
	}

	Window* getWindow() {
		return window.get();
	}

	bool pollEvent(SDL_Event* event) {
		return sdl3_poll_event(lib, event);
	}

private:
	HMODULE lib;
	std::unique_ptr<Window> window;
	std::unique_ptr<Render> renderer;
};
