#pragma once

HMODULE sdl3_load() {
	HMODULE sdl3 = LoadLibraryA("SDL3.dll");
	if (!sdl3) {
		std::cerr << "Fail to load SDL3.dll, error: " << GetLastError() << std::endl;
		exit(1);
	}
	return sdl3;
}

bool sdl3_init(HMODULE sdl3, uint32_t init_flags) {
	SDL_Init _sdl3_init = (SDL_Init)GetProcAddress(sdl3, "SDL_Init");
	if (!_sdl3_init) {
		std::cerr << "Fail to load SDL_Init, error: " << GetLastError() << std::endl;
		FreeLibrary(sdl3);
		exit(1);
	}
	return _sdl3_init(init_flags);
}

void sdl3_quit(HMODULE sdl3) {
	SDL_Quit _sdl3_quit = (SDL_Quit)GetProcAddress(sdl3, "SDL_Quit");
	if (!_sdl3_quit) {
		std::cerr << "Fail to load SDL_Quit, error: " << GetLastError() << std::endl;
		FreeLibrary(sdl3);
		exit(1);
	}
	_sdl3_quit();
}

void sdl3_delay(HMODULE sdl3, Uint32 ms) {
	SDL_Delay _sdl3_delay = (SDL_Delay)GetProcAddress(sdl3, "SDL_Delay");
	if (!_sdl3_delay) {
		std::cerr << "Fail to load SDL_Delay, error: " << GetLastError() << std::endl;
		FreeLibrary(sdl3);
		exit(1);
	}
	_sdl3_delay(ms);
}

bool sdl3_poll_event(HMODULE sdl3, SDL_Event* event) {
	SDL_PollEvent _sdl3_poll_event = (SDL_PollEvent)GetProcAddress(sdl3, "SDL_PollEvent");
	return _sdl3_poll_event(event);
}
