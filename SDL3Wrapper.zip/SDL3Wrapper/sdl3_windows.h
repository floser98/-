#pragma once
#include <iostream>
#include "sdl3_defs.h"

inline void* sdl3_create_window(HMODULE sdl3, std::string title, int w, int h, uint64_t window_flags) {
	SDL_CreateWindow _sdl3_create_window = (SDL_CreateWindow)GetProcAddress(sdl3, "SDL_CreateWindow");
	if (!_sdl3_create_window) {
		std::cerr << "Fail to load SDL_CreateWindow, error: " << GetLastError() << std::endl;
		FreeLibrary(sdl3);
		exit(1);
	}
	void* window = _sdl3_create_window(title, w, h, window_flags);
	if (!window) {
		std::cerr << "Fail to create window, error: " << GetLastError() << std::endl;
		FreeLibrary(sdl3);
		exit(1);
	}
	return window;
}

inline void sdl3_destroy_window(HMODULE sdl3, void* window) {
	SDL_DestroyWindow _sdl3_destroy_window = (SDL_DestroyWindow)GetProcAddress(sdl3, "SDL_DestroyWindow");
	if (!_sdl3_destroy_window) {
		std::cerr << "Fail to load SDL_DestroyWindow, error: " << GetLastError() << std::endl;
		FreeLibrary(sdl3);
		exit(1);
	}
	_sdl3_destroy_window(window);
}
