#pragma once

static class Configurator {
public:
	inline static SDL3* SDL_Config(
		uint32_t init_flags, 
		uint64_t window_flags,
		std::string name,
		int width, int height
	) {
		SDL3* sdl3 = new SDL3(init_flags);
		sdl3->createWindow(name, width, height, window_flags);
		sdl3->createRenderer();
		return sdl3;
	}
};